// $Id: alphabet.cpp 391 2005-06-12 12:44:57Z ninio $

#include "alphabet.h"

alphabet::~alphabet(){}
// this must be here. see Effective c++ page 63 (item 14, constructors, destructors, 
// assignment
